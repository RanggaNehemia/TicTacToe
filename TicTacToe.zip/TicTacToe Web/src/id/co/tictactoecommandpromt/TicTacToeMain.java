package id.co.tictactoecommandpromt;

public class TicTacToeMain {
	
	public static void main(String[] args) {
	      TicTacToeCMD TTT = new TicTacToeCMD(5,5);
	      TTT.play();
	   }
}
